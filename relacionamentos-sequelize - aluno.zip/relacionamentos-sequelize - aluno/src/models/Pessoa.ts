import { timeStamp } from 'console'
import { Model,DataTypes } from 'sequelize'
import { sequelize } from '../instances/mysql'

export interface PessoaInstance extends Model{
    idPessoa:number,
    nome:string,
    cursoPreferido:number //fk de cursos
}

export const Pessoa = sequelize.define<PessoaInstance>('Pessoa',{
    idPessoa:{
        primaryKey:true,
        type:DataTypes.INTEGER,
        autoIncrement:true
    },
    nome:{
        type:DataTypes.STRING,
        allowNull:false
    },
    cursoPreferido:{
        type:DataTypes.INTEGER,
        references:{
            model:'cursos',
            key:'idCurso'
        },
        allowNull:true
    },
},{
    tableName:'pessoa',
    timestamps:false,
})
Pessoa.belongsTo( Curso,{foreignKey:'cursoPreferido', as 'curso'})